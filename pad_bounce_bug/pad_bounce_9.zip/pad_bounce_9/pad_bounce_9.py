import sys, pygame, time, math, os
pygame.init()

def render_level (brick_positions, assets_dir):
    bricks = []
    brick_stats = []
    for brick_row in brick_positions:
        temp_brick_row = []
        temp_brick_stats_row = []
        for brick_column in brick_row:
            if brick_column == '-':
                temp_brick_row.append('')
                temp_brick_stats_row.append(['', 0])
            if brick_column == '@':
                temp_brick_row.append(pygame.image.load(assets_dir+'brick_1.png'))
                temp_brick_stats_row.append(['brick_1', 1])
            if brick_column == '#':
                temp_brick_row.append(pygame.image.load(assets_dir+'brick_2_1.png'))
                temp_brick_stats_row.append(['brick_2', 2])
            if brick_column == '$':
                temp_brick_row.append(pygame.image.load(assets_dir+'brick_3_1.png'))
                temp_brick_stats_row.append(['brick_3', 3])
            if brick_column == 'o':
                temp_brick_row.append(pygame.image.load(assets_dir+'bomb_1.png'))
                temp_brick_stats_row.append(['bomb_1', 1])
            if brick_column == '%':
                temp_brick_row.append(pygame.image.load(assets_dir+'steel_brick.png'))
                temp_brick_stats_row.append(['steel_brick', 10000000000000000])
            if brick_column == '^':
                temp_brick_row.append(pygame.image.load(assets_dir+'bouncy_brick_1.png'))
                temp_brick_stats_row.append(['bouncy_brick', 1])
            if brick_column == 'T':
                temp_brick_row.append(pygame.image.load(assets_dir+'troll_brick_1.png'))
                temp_brick_stats_row.append(['troll_brick', 1])
        bricks.append(temp_brick_row)
        brick_stats.append(temp_brick_stats_row)
    brick_rects = []
    for brick_row in bricks:
        temp_brick_row = []
        for brick_column in brick_row:
            try:
                temp_brick_row.append(brick_column.get_rect())
            except:
                temp_brick_row.append('')
        brick_rects.append(temp_brick_row)
    brick_row_x, brick_row_y = 20, 20
    for brick_row in brick_rects:
        for brick_column in brick_row:
            try:
                brick_column[0] += brick_row_x
                brick_column[1] += brick_row_y
            except:
                useless = True
            brick_row_x += 20
        brick_row_x = 20
        brick_row_y += 20
    brick_count = 0
    for brick_stats_row in brick_stats:
        for brick in brick_stats_row:
            if brick[0] == 'brick_1':
                brick_count += 1
            elif brick[0] == 'brick_2':
                brick_count += 2
            elif brick[0] == 'brick_3':
                brick_count += 3
            elif brick[0] == 'bomb_1':
                brick_count += 1
            elif brick[0] == 'bouncy_brick':
                brick_count += 1
    return [bricks, brick_rects, brick_count, brick_stats]

def text (string, screen, color, position, size, update=False):
    font = pygame.font.Font(None, size)
    text = font.render(string, 1, (color[0], color[1], color[2]))
    textpos = text.get_rect(centerx=position[0], centery=position[1])
    screen.blit(text, textpos)
    if update:
        pygame.display.flip()

# @ - standard
# # - 2 health
# $ - 3 health
# o - bomb
# % - steel
# ^ - bouncy brick
# T - troll brick
#brick_positions: 3*30 
#                    ------------------------------
brick_positions = [['--------------@@--------------',
                    '------------@@@@@@------------',
                    '--------------@@--------------'],
                   ['-@----@@--------------@@----@-',
                    '------@@------##------@@------',
                    '-@--------------------------@-'],
                   ['------------$----##-----------',
                    '--------------@@--#-----------',
                    '------------$----##-----------'],
                   ['-------------@@@@-------------',
                    '-------------@@@@-------------',
                    '-------------%%%%-------------'],
                   ['----@--------#@@#--------@----',
                    '----o@-------@oo@-------@o----',
                    '----@%-------$@@$-------%@----'],
                   ['-------------@@@@-------------',
                    '----$----#---@@@@---#----$----',
                    '-------------%$^%-------------'],
                   ['-------@@@@@------@@@@@-------',
                    '--$------------------------$--',
                    '--^-----------##-----------o--'],
                   ['-----@--------@@--------@-----',
                    '----@o@------@o@@------@o@----',
                    '-----@--------@^--------@-----'],
                   ['-----@@--@----@@@@------------',
                    '-----@-@-@----@--@------------',
                    '-----@--@@----@@@@--@-@-@-----'],
                   ['--------@#o@#$o$#@o#@---------',
                    '---T----$o@$o@#@o$@o$-----T---',
                    '--------@#o@#$o$#@o#@---------']]

level_msg = ['In this level you learn about bricks',
             'Some bricks take more than one hit to destroy',
             'Smilin\'',
             'Some bricks take more than 9999999999999999 hits to destroy',
             'Some bricks go BOOOM!... sometimes',
             'What\'s that green thing?',
             'In the next level there are flowers',
             'They are very beautiful',
             '... you will not win',
             'Have fun!']

assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'

size = screenWidth, screenHeight = 640, 480
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Brick Smasher')
icon = pygame.image.load(assets_dir+"icon.png")
pygame.display.set_icon(icon)
loading_screen = pygame.image.load(assets_dir+'screen.png')
loading_screen_rect = loading_screen.get_rect()
screen.blit(loading_screen, loading_screen_rect)
pygame.display.flip()
time.sleep(4)

bricks = render_level(brick_positions[0], assets_dir)[0]
brick_rects = render_level(brick_positions[0], assets_dir)[1]
brick_count = render_level(brick_positions[0], assets_dir)[2]
brick_stats = render_level(brick_positions[0], assets_dir)[3]

padwidth, padheight = 80, 20
ballsize = 20
speed = [0, 0]
white = 255, 255, 255
ball = pygame.image.load(assets_dir+"ball.png")
ballrect = ball.get_rect()
pad = pygame.image.load(assets_dir+"pad.png")
padrect = pad.get_rect()
padrect[0] = (screenWidth//2)-(padwidth//2)
padrect[1] = int(screenHeight*0.9)
ballrect[0] = padrect[0]+(padwidth//2)-(ballsize//2)
ballrect[1] = 5
pygame.key.set_repeat(1)
tick_timer = 0
static_speed = 3

game_over = pygame.image.load(assets_dir+'game_over.png')
game_over_rect = game_over.get_rect()
you_win = pygame.image.load(assets_dir+'you_win.png')
you_win_rect = you_win.get_rect()
pause = pygame.image.load(assets_dir+'pause.png')
pause_rect = pause.get_rect()
game_over_troll = pygame.image.load(assets_dir+'game_over_troll.png')
game_over_troll_rect = game_over_troll.get_rect()


levels_won = 0
brick_hits = 0

right_key_pressed = False
left_key_pressed = False
launched = False

while True:
    ballcenter_x = (ballrect.right+ballrect.left)//2
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif (event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT) and (padrect[0]-1 > 0):
            padrect[0] -= 3
            left_key_pressed == True
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT and (padrect[0]+padwidth+1 < screenWidth):
            padrect[0] += 3
            right_key_pressed = True
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            speed = [0, -3]
            launched = True
        elif event.type == pygame.KEYUP and event.key == pygame.K_g:
            brick_hits = brick_count
        elif event.type == pygame.KEYUP and event.key == pygame.K_p:
            paused = True
            screen.blit(pause, pause_rect)
            pygame.display.flip()
            while paused:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        sys.exit()
                    elif event.type == pygame.KEYUP and event.key == pygame.K_p:
                        paused = False
                    
    if (ballrect.bottom in [padrect.top-3,padrect.top-2,padrect.top-1,padrect.top,padrect.top+1,padrect.top+2,padrect.top+3]) and (tick_timer == 0):
        if (ballcenter_x > (padrect.left+padwidth//4)) and (ballcenter_x < (padrect.right-padwidth//4)):
            speed[1] *= -1
            tick_timer = 20
        elif (ballrect.right > padrect.left) and (ballcenter_x <= (padrect.left+padwidth//4)):
            '''
            x0, y0 : point of origin of circle
            x1, y1 : point of impact
            a : slope of initial line
            b : y-intercept of initial line
            theta0 : angle of initial line
            theta1 : angle of raduis
            theta2 : angle of second line
            '''
            x0 = padrect.bottom
            y0 = padrect.left+(padwidth//4)
            x1 = ballrect.bottom
            try:
                y1 = math.sqrt(400 - (x1 - x0)**2) + y0
            except:
                y1 = math.sqrt(-1*(400 - (x1 - x0)**2)) + y0
            try:
                a = speed[1]/speed[0]
            except:
                a = 1000000000000
            theta0 = math.atan(a)
            theta1 = math.atan((y1-y0)/(x1-x0))
            theta2 = 2*theta0 - theta1
            slope = math.tan(theta2)
            speed[0] = -1*(static_speed//(math.sqrt((slope**2)+1)))
            speed[1] = (static_speed*slope)//(math.sqrt((slope**2)+1))
            
            if speed[1] > 0:
                speed[1] *= -1
            tick_timer = 20
        elif (ballrect.left < padrect.right) and (ballcenter_x >= (padrect.right-padwidth//4)):
            '''
            x0, y0 : point of origin of circle
            x1, y1 : point of impact
            a : slope of initial line
            b : y-intercept of initial line
            theta0 : angle of initial line
            theta1 : angle of raduis
            theta2 : angle of second line
            '''
            x0 = padrect.bottom
            y0 = padrect.right-(padwidth//4)
            x1 = ballrect.bottom
            try:
                y1 = math.sqrt(400 - (x1 - x0)**2) + y0
            except:
                y1 = math.sqrt(-1*(400 - (x1 - x0)**2)) + y0
            try:
                a = speed[1]/speed[0]
            except:
                a = 1000000000000
            theta0 = math.atan(a)
            theta1 = math.atan((y1-y0)/(x1-x0))
            theta2 = 2*theta0 - theta1
            slope = math.tan(theta2)
            speed[0] = (static_speed//(math.sqrt((slope**2)+1)))
            speed[1] = (static_speed*slope)//(math.sqrt((slope**2)+1))
            if speed[1] > 0:
                speed[1] *= -1
            tick_timer = 20
        elif (ballrect.right > padrect.left-(padwidth//4)) and (ballcenter_x <= (padrect.left+padwidth//4)) and (left_key_pressed or right_key_pressed):
            '''
            x0, y0 : point of origin of circle
            x1, y1 : point of impact
            a : slope of initial line
            b : y-intercept of initial line
            theta0 : angle of initial line
            theta1 : angle of raduis
            theta2 : angle of second line
            '''
            x0 = padrect.bottom
            y0 = padrect.left+(padwidth//4)
            x1 = ballrect.bottom
            try:
                y1 = math.sqrt(400 - (x1 - x0)**2) + y0
            except:
                y1 = math.sqrt(-1*(400 - (x1 - x0)**2)) + y0
            try:
                a = speed[1]/speed[0]
            except:
                a = 1000000000000
            theta0 = math.atan(a)
            theta1 = math.atan((y1-y0)/(x1-x0))
            theta2 = 2*theta0 - theta1
            slope = math.tan(theta2)
            speed[0] = -1*(static_speed//(math.sqrt((slope**2)+1)))
            speed[1] = (static_speed*slope)//(math.sqrt((slope**2)+1))
            
            if speed[1] > 0:
                speed[1] *= -1
            tick_timer = 20
        elif (ballrect.left < padrect.right+(padwidth//4)) and (ballcenter_x >= (padrect.right-padwidth//4)) and (left_key_pressed or right_key_pressed):
            '''
            x0, y0 : point of origin of circle
            x1, y1 : point of impact
            a : slope of initial line
            b : y-intercept of initial line
            theta0 : angle of initial line
            theta1 : angle of raduis
            theta2 : angle of second line
            '''
            x0 = padrect.bottom
            y0 = padrect.right-(padwidth//4)
            x1 = ballrect.bottom
            try:
                y1 = math.sqrt(400 - (x1 - x0)**2) + y0
            except:
                y1 = math.sqrt(-1*(400 - (x1 - x0)**2)) + y0
            try:
                a = speed[1]/speed[0]
            except:
                a = 1000000000000
            theta0 = math.atan(a)
            theta1 = math.atan((y1-y0)/(x1-x0))
            theta2 = 2*theta0 - theta1
            slope = math.tan(theta2)
            speed[0] = (static_speed//(math.sqrt((slope**2)+1)))
            speed[1] = (static_speed*slope)//(math.sqrt((slope**2)+1))
            if speed[1] > 0:
                speed[1] *= -1
            tick_timer = 20
    if ballrect.left < 0 or ballrect.right > screenWidth:
        speed[0] = -speed[0]
    elif ballrect.top <= 0:
        speed[1] = -speed[1]
    elif ballrect.top > screenHeight:
        screen.fill(white)
        screen.blit(game_over, game_over_rect)
        pygame.display.flip()
        time.sleep(5)
        sys.exit()
    
    if speed[1] > 0 and speed[1] < 0.5:
        speed[1] = 1
    if speed[1] == 0 and launched:
        speed[1] = 1
    if speed[1] < 0 and speed[1] > -0.5:
        speed[1] = -1
    
    ballrect[0] += speed[0]
    ballrect[1] += speed[1]
    
    if speed == [0, 0]:
        ballrect[0] = padrect.left + (padwidth//2) - (ballsize//2)
        ballrect[1] = padrect.top - ballsize
    
    screen.fill(white)
    screen.blit(ball, ballrect)
    screen.blit(pad, padrect)
    brick_counter_row = 0
    brick_counter_index = 0
    for brick_row in brick_rects:
        for brick in brick_row:
            if type(brick) != type(''):
                if (ballrect.bottom >= brick.top) and (ballrect.top <= brick.bottom) and (ballrect.left <= brick.right) and (ballrect.right >= brick.left) and (tick_timer == 0):
                    if ((ballrect.left + (ballsize//2)) <= brick.right) and ((ballrect.left + (ballsize//2)) >= brick.left):
                        speed[1] *= -1
                        if speed[1] > 0 and speed[1] < 0.5:
                            speed[1] = 1
                        elif speed[1] < 0 and speed[1] > -0.5:
                            speed[1] = -1
                    elif ((ballrect.top + (ballsize//2)) <= brick.bottom) and ((ballrect.top + (ballsize//2)) >= brick.top):
                        speed[0] *= -1
                    else:
                        speed[0] *= -1
                        speed[1] *= -1
                    if brick_stats[brick_counter_row][brick_counter_index][0] == 'brick_1':
                        brick_stats[brick_counter_row][brick_counter_index][1] -= 1
                        if brick_stats[brick_counter_row][brick_counter_index][1] > 0:
                            bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_1.png')
                            brick_hits += 1
                        else:
                            brick_rects[brick_counter_row][brick_counter_index] = ''
                            brick_hits += 1
                    if (brick_stats[brick_counter_row][brick_counter_index][0] == 'brick_2') and (tick_timer == 0):
                        brick_stats[brick_counter_row][brick_counter_index][1] -= 1
                        if brick_stats[brick_counter_row][brick_counter_index][1] > 0:
                            bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_2_2.png')
                            brick_hits += 1
                        else:
                            brick_rects[brick_counter_row][brick_counter_index] = ''
                            brick_hits += 1
                    if brick_stats[brick_counter_row][brick_counter_index][0] == 'brick_3':
                        brick_stats[brick_counter_row][brick_counter_index][1] -= 1
                        if brick_stats[brick_counter_row][brick_counter_index][1] == 2:
                            bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_3_2.png')
                            brick_hits += 1
                        elif brick_stats[brick_counter_row][brick_counter_index][1] == 1:
                            bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_3_3.png')
                            brick_hits += 1
                        else:
                            brick_rects[brick_counter_row][brick_counter_index] = ''
                            brick_hits += 1
                    if brick_stats[brick_counter_row][brick_counter_index][0] == 'bouncy_brick':
                        brick_stats[brick_counter_row][brick_counter_index][1] -= 1
                        if brick_stats[brick_counter_row][brick_counter_index][1] > 0:
                            bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'bouncy_brick_1.png')
                            brick_hits += 1
                        else:
                            brick_rects[brick_counter_row][brick_counter_index] = ''
                            brick_hits += 1
                            speed[0] *= 2
                            speed[1] *= 2
                            static_speed *= 2
                    if brick_stats[brick_counter_row][brick_counter_index][0] == 'troll_brick':
                        screen.fill(white)
                        screen.blit(game_over_troll, game_over_troll_rect)
                        pygame.display.flip()
                        time.sleep(5)
                        sys.exit()
                    if brick_stats[brick_counter_row][brick_counter_index][0] == 'bomb_1':
                        brick_rects[brick_counter_row][brick_counter_index] = ''
                        try:
                            if brick_stats[brick_counter_row+1][brick_counter_index][1] != 0 and brick_stats[brick_counter_row+1][brick_counter_index][0] != 'steel_brick':
                                brick_stats[brick_counter_row+1][brick_counter_index][1] -= 1
                                brick_hits += 1
                        except:
                            useless = ''
                        try:
                            if brick_stats[brick_counter_row-1][brick_counter_index][1] != 0 and brick_stats[brick_counter_row-1][brick_counter_index][0] != 'steel_brick':
                                brick_stats[brick_counter_row-1][brick_counter_index][1] -= 1
                                brick_hits += 1
                        except:
                            useless = ''
                        try:
                            if brick_stats[brick_counter_row][brick_counter_index+1][1] != 0 and brick_stats[brick_counter_row][brick_counter_index+1][0] != 'steel_brick':
                                brick_stats[brick_counter_row][brick_counter_index+1][1] -= 1
                                brick_hits += 1
                        except:
                            useless = ''
                        try:
                            if brick_stats[brick_counter_row][brick_counter_index-1][1] != 0 and brick_stats[brick_counter_row-1][brick_counter_index-1][0] != 'steel_brick':
                                brick_stats[brick_counter_row][brick_counter_index-1][1] -= 1
                                brick_hits += 1
                        except:
                            useless = ''
                        brick_hits += 1
#                    else:
#                        brick_rects[brick_counter_row][brick_counter_index] = ''
                    tick_timer = 5
            brick_counter_index += 1
        brick_counter_index = 0
        brick_counter_row += 1
    brick_counter_row = 0
    brick_counter_index = 0
    for brick_row in brick_stats:
        for brick in brick_row:
            if brick[1] < 1:
                brick_rects[brick_counter_row][brick_counter_index] = ''
            else:
                if brick[0] == 'brick_2':
                    if brick[1] == 1:
                        bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_2_2.png')
                if brick[0] == 'brick_3':
                    if brick[1] == 2:
                        bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_3_2.png')
                    if brick[1] == 1:
                        bricks[brick_counter_row][brick_counter_index] = pygame.image.load(assets_dir+'brick_3_3.png')
            brick_counter_index += 1
        brick_counter_index = 0
        brick_counter_row += 1
    brick_counter_row = 0
    brick_counter_index = 0
    for brick_row in bricks:
        for brick in brick_row:
            try:
                screen.blit(brick, brick_rects[brick_counter_row][brick_counter_index])
            except:
                useless = 1
            brick_counter_index += 1
        brick_counter_index = 0
        brick_counter_row += 1
    text(level_msg[levels_won], screen, [0, 0, 0], [320, 240], 25)
    text('Press P to pause', screen, [0, 0, 0], [580, 10], 18)
    pygame.display.flip()
    if tick_timer > 0:
        tick_timer -= 1
    right_key_pressed = False
    left_key_pressed = False
    if brick_hits == brick_count:
        levels_won += 1
        try:
            bricks = render_level(brick_positions[levels_won], assets_dir)[0]
            brick_rects = render_level(brick_positions[levels_won], assets_dir)[1]
            brick_count = render_level(brick_positions[levels_won], assets_dir)[2]
            brick_stats = render_level(brick_positions[levels_won], assets_dir)[3]
            brick_hits = 0
            speed = [0, 0]
            launched = False
        except:
            screen.fill(white)
            screen.blit(you_win, you_win_rect)
            pygame.display.flip()
            time.sleep(5)
            sys.exit()
    time.sleep(0.0075)