from subprocess import check_output
import baseconv, os, random
base2 = baseconv.BaseConverter('01')

def set_properties ():
    properties = open('init.aesp', 'r', encoding='utf-8')
    d_settings = ['', '', '', [randomStr(), randomStr(), randomStr()], 'utf-8', 'e']
    d_debug = ['true', 'true', 'true', 5, 1]
    h_debug = ['false', 'false', 'false', 101, 0]
    d_p_input = ['all', 'all', 'true', 'true', 'true']
    d_p_output = ['true', 'true', 'true', 'true', 'true']
    d_adv = ['.aes', '.aes.dec', '.aes.chk']

    settings = ['', '', '', [], [], 'e']
    debug = ['', '', '', 0, 0]
    p_input = ['', '', '', '', '']
    p_output = ['', '', '', '', '']
    adv = ['', '', '']

    mode = 0
    for command in properties:
        command = command.strip()
        if command == '[Settings]':
            mode = 1
        elif command == '[Debug]':
            mode = 2
        elif command == '[P_Input]':
            mode = 3
        elif command == '[P_Output]':
            mode = 4
        elif command == '[Adv]':
            mode = 5
        elif len(command) > 0 and command[0] == "[" and command[len(command)-1] == "]":
            mode = 0
        else:
            if mode == 1:
                if command[:6] == 'input=':
                    settings[0] = command[6:]
                elif command[:7] == 'output=':
                    settings[1] = command[7:]
                elif command[:11] == 'chk_output=':
                    settings[2] = command[11:]
                elif command[:5] == 'keys=':
                    if len(command[5:]) > 0:
                        settings[3] = string2List(command[5:], 'not_i')
                    else:
                        settings[3] = d_settings[3]
                elif command[:8] == 'passEnc=':
                    settings[4] = command[8:]
                elif command[:9] == 'sequence=':
                    settings[5] = command[9:]
            elif mode == 2:
                if command[:11] == 'printInput=':
                    debug[0] = command[11:]
                elif command[:12] == 'printOutput=':
                    debug[1] = command[12:]
                elif command[:10] == 'printProg=':
                    debug[2] = command[10:]
                elif command[:8] == 'progInt=':
                    debug[3] = command[8:]
                elif command[:8] == 'progRnd=':
                    debug[4] = command[8:]
                elif command[:6] == 'debug=':
                    if command[6:] == 'default':
                        debug = d_debug
                    elif command[6:] == 'hidden':
                        debug = h_debug
            elif mode == 3:
                if command[:10] == 'printKeys=':
                    if (command[10] == '[') and (command[len(command)-1] == ']'):
                        p_input[0] = string2List(command[10:], 'i')
                    else:
                        p_input[0] = command[10:]
                elif command[:13] == 'printNumKeys=':
                    if (command[13] == '[') and (command[len(command)-1] == ']'):
                        p_input[1] = string2List(command[13:], 'i')
                    else:
                        p_input[1] = command[13:]
                elif command[:15] == 'printInputFrom=':
                    p_input[2] = command[15:]
                elif command[:14] == 'printOutputTo=':
                    p_input[3] = command[14:]
                elif command[:17] == 'printChkOutputTo=':
                    p_input[4] = command[17:]
            elif mode == 4:
                if command[:16] == 'printOutputedTo=':
                    p_output[0] = command[16:]
                elif command[:19] == 'printChkOutputedTo=':
                    p_output[1] = command[19:]
                elif command[:14] == 'printInitSize=':
                    p_output[2] = command[14:]
                elif command[:15] == 'printFinalSize=':
                    p_output[3] = command[15:]
                elif command[:15] == 'printCompRatio=':
                    p_output[4] = command[15:]
            elif mode == 5:
                if command[:8] == 'encLtrs=':
                    adv[0] = command[8:]
                elif command[:8] == 'decLtrs=':
                    adv[1] = command[8:]
                elif command[:8] == 'chkLtrs=':
                    adv[2] = command[8:]
    
    settingsCounter = 0
    while settingsCounter != len(settings):
        if len(settings[settingsCounter]) == 0:
            settings[settingsCounter] == d_settings[settingsCounter]
        settingsCounter += 1
    
    debugCounter = 0
    while debugCounter != len(debug):
        if typeStr(debug[debugCounter]) != "<class 'int'>":
            if len(debug[debugCounter]) == 0:
                debug[debugCounter] == d_debug[debugCounter]
        debugCounter += 1
    
    p_inputCounter = 0
    while p_inputCounter != len(p_input):
        if len(p_input[p_inputCounter]) == 0:
            p_input[p_inputCounter] == d_p_input[p_inputCounter]
        p_inputCounter += 1
    
    p_outputCounter = 0
    while p_outputCounter != len(p_output):
        if len(p_output[p_outputCounter]) == 0:
            p_output[p_outputCounter] == d_p_output[p_outputCounter]
        p_outputCounter += 1
    
    advCounter = 0
    while advCounter != len(adv):
        if len(adv[advCounter]) == 0:
            adv[advCounter] == d_adv[advCounter]
        advCounter += 1
    
    return settings, debug, p_input, p_output, adv

def randomStr():
    length = random.randint(1, 15)
    counter = 0
    fStr = ''
    while counter <= length:
        fStr += chr(random.randint(48, 126))
        counter += 1
    return fStr

def typeStr (object):
    answer = str(type(object))
    return answer

def string2List (string, flag):
    theList = []
    string = string[1:len(string)-1]
    fStr = ''
    for chtr in string:
        if chtr == ',':
            if flag == 'i':
                theList.append(int(fStr))
            else:
                theList.append(fStr)
            fStr = ''
        else:
            fStr += chtr
    if flag == 'i':
        theList.append(int(fStr))
    else:
        theList.append(fStr)
    return theList

def string2ListByChtr (string, chtrFlag):
    theList = []
    fStr = ''
    for chtr in string:
        if chtr == chtrFlag:
            theList.append(chtr)
            fStr = ''
        else:
            fStr += chtr
    theList.append(chtr)
    return theList

def list2Str (theList):
    fStr = ''
    for theEntry in theList:
        fStr += str(theEntry) + ', '
    fStr = fStr[:len(fStr)-2]
    return fStr

def list2initStr (theList):
    fStr = '['
    for theEntry in theList:
        fStr += str(theEntry) + ','
    fStr = fStr[:len(fStr)-1]
    fStr += ']'
    return fStr

def getSizeStr (location):
    intStr = getSize(location)
    letter = ""
    if intStr < 1000:
        letter = "B"
        fStr = str(intStr) + letter
    if intStr >= 1000 and intStr < 1000000:
        letter = "kB"
        fStr = str(intStr/1000) + letter
    if intStr >= 1000000 and intStr < 1000000000:
        letter = "MB"
        fStr = str(intStr/1000000) + letter
    if intStr >= 1000000000:
        letter = "GB"
        fStr = str(intStr/1000000000) + letter
    return fStr

def getSize (location):
    fileList = ((str(check_output("dir " + location + " /a:-d", shell=True).decode())).split())
    flag = False
    for fileStr in fileList:
        if flag:
            theStr = fileStr
            break
        else:
            if fileStr == 'File(s)':
                flag = True
    f_fileStr = ''
    for digit in theStr:
        if digit != ",":
            f_fileStr += digit
    return int(f_fileStr)

def s2b (letter):
    try:
        bStr = int.from_bytes(letter, byteorder='little')
    except:
        try:
            bStr = ord(letter)
        except:
            bStr = letter
    bStr = base2.encode(bStr)
    while len(bStr) < 8:
        bStr = '0' + bStr
    return bStr

def encrypt (letter, key, flag):
    '''
    letter - one byte.
    key - 0-7
    flag - 'e' or 'd'
    '''
    if flag == 'd':
        key = 8 - key
    bStr = s2b(letter)
    fStr = bStr[key:] + bStr[:key]
    return bytes([int(base2.decode(fStr))])

def encode (msg, password, flag):
    '''
    msg - 2 bytes
    password - one byte or letter
    flag - 'e' or 'd'
    '''
    bPass = s2b(password)
    keys = [int(base2.decode(bPass[:3])), int(base2.decode(bPass[5:]))]
    answer = b''
    answer += encrypt(msg[0],keys[0],flag)
    answer += encrypt(msg[1],keys[1],flag)
    return answer

def fEncode (msg, password, flag):
    '''
    msg - any length (in bytes)
    password - one bytes or letter
    flag - 'e' or 'd'
    '''
    msgList = []
    counter = 0
    odd = True
    if len(msg) % 2 == 0:
        odd = False
    while (counter+2) <= len(msg):
        try:
            msgList.append(msg[counter:counter+2])
            counter += 2
        except:
            break
    fList = b''
    for msgListEntry in msgList:
        fList += encode(msgListEntry,password,flag)
    if odd:
        fList += msg[len(msg)-1:]
    return fList

def sequence (msg, password, flag, printStr):
    '''
    msg - any length (in bytes)
    password - any length (in bytes or str)
    flag - 'e' or 'd'
    '''
    answer = b''
    counter = 0
    for passLtr in password:
        os.system('cls')
        print(printStr)
        prog = int(round(counter*100/len(password)))
        opSpace = ''
        if counter == 0:
            opSpace = ' '
        print(str(prog) + '%  ' + opSpace + '#'*2*int(round(prog/10)) + '-'*2*(10-int(round(prog/10))))
        answer += fEncode(msg, passLtr, flag)
        counter += 1
    return answer[:len(msg)]

def reverse (theList):
    counter = 1
    fList = ''
    while True:
        try:
            fList += str(theList[len(theList)-counter])
            counter += 1
        except:
            return fList[:int(len(fList)/2)]

os.system('cls')

propertiesList = set_properties()
settings = propertiesList[0]
debug = propertiesList[1]
p_input = propertiesList[2]
p_output = propertiesList[3]
adv = propertiesList[4]

input_file_path = settings[0]
output_file_path = settings[1]
if (settings[2] == 'false') or (settings[2] == ''):
    bool_chk_output = False
    chk_output_file_path = ''
else:
    bool_chk_output = True
    chk_output_file_path = settings[2]
iterations = len(settings[3])
passwords = settings[3]
num_passwords = settings[4]
flag = settings[5]

if debug[0].capitalize() == 'True':
    printInput = True
else:
    printInput = False
if debug[1].capitalize() == 'True':
    printOutput = True
else:
    printOutput = False
if debug[2].capitalize() == 'True':
    printProg = True
else:
    printProg = False
progInt = debug[3]
progRnd = debug[4]

if p_input[0] == 'all':
    printKeys = list2Str(passwords)
else:
    printKeys = ''
    for printKeyEntry in p_input[0]:
        printKeys += passwords[printKeyEntry-1] + ', '
    printKeys = printKeys[:len(printKeys)-2]
bPrintKeys = True
if len(p_input[0]) == 0:
    bPrintKeys = False
if p_input[1] == 'all':
    printNumKeys = list2Str(num_passwords)
else:
    printNumKeys = ''
    for printNumKeyEntry in p_input[1]:
        printNumKeys += str(num_passwords[printNumKeyEntry-1]) + ', '
    printNumKeys = printNumKeys[:len(printNumKeys)-2]
bPrintNumKeys = True
if len(p_input[1]) == 0:
    bPrintNumKeys = False
if p_input[2].capitalize() == 'True':
    printInputFrom = True
else:
    printInputFrom = False
if p_input[3].capitalize() == 'True':
    printOutputTo = True
else:
    printOutputTo = False
if p_input[4].capitalize() == 'True':
    printChkOutputTo = True
else:
    printChkOutputTo = False

if p_output[0].capitalize() == 'True':
    printOutputedTo = True
else:
    printOutputedTo = False
if p_output[1].capitalize() == 'True':
    printChkOutputedTo = True
else:
    printChkOutputedTo = False
if p_output[2].capitalize() == 'True':
    printInitSize = True
else:
    printInitSize = False
if p_output[3].capitalize() == 'True':
    printFinalSize = True
else:
    printFinalSize = False
if p_output[4].capitalize() == 'True':
    printCompRatio = True
else:
    printCompRatio = False

encLtrs = adv[0]
decLtrs = adv[1]
chkLtrs = adv[2]

textFileName = input_file_path
ciphertextFileName = output_file_path + '.' + encLtrs
plaintextFileName = chk_output_file_path + chkLtrs
dectextFileName = output_file_path + decLtrs

versions = open('versions.txt', 'r')
versions_list = []
for versions_str in versions:
    versions_list.append(versions_str)

printVersions = 'Using ED_B version ' + versions_list[3] + '\n'

print(printVersions)
if flag == 'e':
    printInputStr = ''
    if printInput:
        if printInputFrom:
            printInputStr += 'Inputing from: ' + textFileName
        if printInputFrom and bPrintKeys:
            printInputStr += '\n'
        if bPrintKeys:
            printInputStr += 'Encoding using key: ' + printKeys
        if bPrintKeys and printOutputTo:
            printInputStr += '\n'
        if printOutputTo:
            printInputStr += 'Outputing to: ' + ciphertextFileName
        if printOutputTo and printChkOutputTo and bool_chk_output:
            printInputStr += '\n'
        if printChkOutputTo and bool_chk_output:
            printInputStr += 'Check outputing to: ' + plaintextFileName
        print(printInputStr)
    print('Reading file...')
    print('0%   ----------')
    if typeStr(passwords) == "<class 'str'>":
        key = passwords
    else:
        key = passwords[0]
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('10%  ##---------')
    text_file = open(textFileName, 'rb')
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('20%  ####----------------')
    text = text_file.read()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('90%  ##################--')
    text_file.close()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('0%   --------------------')
    printEncStrInput = printInputStr + '\n'
    if printInput == False:
        printEncStrInput = ''
    printEncStr = printVersions + '\n' +printEncStrInput + 'Reading file...\n100% ####################\nEncrypting file...'
    ciphertext = sequence(text, key, 'e', printEncStr)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('0%   --------------------')
    os.system('copy /y ' + textFileName + ' ' + ciphertextFileName)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('10%  ##------------------')
    ciphertext_file = open(ciphertextFileName, 'wb')
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('20%  ####----------------')
    ciphertext_file.write(ciphertext)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('90%  ##################--')
    ciphertext_file.close()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Encrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('100% ####################')
    
    if bool_chk_output:
        os.system('cls')
        print(printVersions)
        if printInput:
            print(printInputStr)
        print('Reading file...')
        print('100% ####################')
        print('Encrypting file...')
        print('100% ####################')
        print('Writing file...')
        print('100% ####################')
        print('Validating encryption...')
        print('0%   --------------------')
        plaintext_r_file = open(ciphertextFileName, 'rb')
        plaintext_r = plaintext_r_file.read()
        plaintext_r_file.close()
        os.system('cls')
        print(printVersions)
        if printInput:
            print(printInputStr)
        print('Reading file...')
        print('100% ####################')
        print('Encrypting file...')
        print('100% ####################')
        print('Writing file...')
        print('100% ####################')
        print('Validating encryption...')
        print('20%  ####----------------')
        printEncStr = printVersions + '\n' + printEncStrInput + 'Reading file...\n100% ####################\nEncrypting file...\n100% ####################\nWriting file...\n100% ####################\nValidating encryption...'
        plaintext = sequence(plaintext_r, key, 'd', printEncStr)
        os.system('cls')
        print(printVersions)
        if printInput:
            print(printInputStr)
        print('Reading file...')
        print('100% ####################')
        print('Encrypting file...')
        print('100% ####################')
        print('Writing file...')
        print('100% ####################')
        print('Validating encryption...')
        print('100% ####################')
        if plaintext == text:
            print('Success!')
        else:
            print('Error! Plaintext does not match original text.')
    
    if printOutput:
        if printOutputedTo:
            print('Outputed to: ' + ciphertextFileName)
        if printInitSize:
            print('Initial file size: ' + getSizeStr(textFileName))
        if printFinalSize:
            print('Final file size: ' + getSizeStr(ciphertextFileName))
        if printCompRatio:
            print('Compression ratio: ' + str(round((getSize(ciphertextFileName)*100/getSize(textFileName)), 1)) + '%')

elif flag == 'd':
    printInputStr = ''
    if printInput:
        if printInputFrom:
            printInputStr += 'Inputing from: ' + textFileName
        if printInputFrom and bPrintKeys:
            printInputStr += '\n'
        if bPrintKeys:
            printInputStr += 'Decoding using key: ' + printKeys
        if bPrintKeys and printOutputTo:
            printInputStr += '\n'
        if printOutputTo:
            printInputStr += 'Outputing to: ' + ciphertextFileName + '.' + adv[1]
    print(printInputStr)
    print('Reading file...')
    print('0%   --------------------')
    if typeStr(passwords) == "<class 'str'>":
        key = passwords
    else:
        key = passwords[0]
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('10%  ##------------------')
    text_file = open(textFileName, 'rb')
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('90%  ##################--')
    text = text_file.read()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    text_file.close()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('0%   --------------------')
    printDecStrInput = printInputStr + '\n'
    printDecStr = printVersions + '\n' + printDecStrInput + 'Reading file...\n100% ####################\nDecrypting file...'
    ciphertext = sequence(text, key, 'd', printDecStr)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('0%   --------------------')
    os.system('copy /y ' + textFileName + ' ' + output_file_path)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('10%  ##------------------')
    ciphertext_file = open(output_file_path, 'wb')
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('20%  ####----------------')
    ciphertext_file.write(ciphertext)
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('90%  ##################--')
    ciphertext_file.close()
    os.system('cls')
    print(printVersions)
    if printInput:
        print(printInputStr)
    print('Reading file...')
    print('100% ####################')
    print('Decrypting file...')
    print('100% ####################')
    print('Writing file...')
    print('100% ####################')
    if printOutput:
        if printOutputedTo:
            print('Outputed to: ' + output_file_path)
        if printInitSize:
            print('Initial file size: ' + getSizeStr(textFileName))
        if printFinalSize:
            print('Final file size: ' + getSizeStr(output_file_path))
        if printCompRatio:
            print('Compression ratio: ' + str(round((getSize(output_file_path)*100/getSize(textFileName)), 1)) + '%')
exitCode = input('Press ENTER/RETURN to exit...')