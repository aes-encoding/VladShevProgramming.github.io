import os

def list2str (theList):
    fStr = '['
    for theEntry in theList:
        fStr += str(theEntry) + ','
    fStr = fStr[:len(fStr)-1]
    fStr += ']'
    return fStr
os.system('cls')
print('Welcome to the AES setup!')
init_file = open('init.aesp', 'w')

while True:
    input_sequence = input('Do you want to encrypt or decrypt files? (E/D): ').capitalize()
    if input_sequence == 'E':
        sequence = 'e'
        break
    elif input_sequence == 'D':
        sequence = 'd'
        break

inputPath = input('Enter input file location: ')
outputPath = input('Enter output file location: ')
chk_outputPath = input('Enter check-output file location (leave blank for none): ')

while True:
    input_numberof_keys = input('Enter the number of passwords: ')
    try:
        numberof_keys = int(input_numberof_keys)
        if numberof_keys > 0:
            break
    except:
        print('Not a valid number!')

keys = []
keyCounter = 0
while keyCounter != numberof_keys:
    keys.append(input('Enter password: '))
    keyCounter += 1

numKeys = []
keyCounter = 0
while keyCounter != numberof_keys:
    input_numKey = input('Enter combination index: ')
    try:
        numKey = int(input_numKey)
        numKeys.append(numKey)
        keyCounter += 1
    except:
        print('Not a valid number!')

while True:
    input_debug = input('Set debug to default/hidden? (D/H/blank for custom): ').capitalize()
    if input_debug == 'D':
        debug = 'default'
        customDebug = False
        break
    elif input_debug == 'H':
        debug = 'hidden'
        customDebug = False
        break
    elif input_debug == '':
        debug = ''
        customDebug = True
        break

if customDebug:
    while True:
        input_printInput = input('Do you want AES to print the initialization parameters? (Y/N): ').capitalize()
        if input_printInput ==  'Y':
            printInput = 'true'
            break
        elif input_printInput == 'N':
            printInput = 'false'
            break
    
    while True:
        input_printOutput = input('Do you want AES to print the conculsion after finishing? (Y/N): ').capitalize()
        if input_printOutput ==  'Y':
            printOutput = 'true'
            break
        elif input_printOutput == 'N':
            printOutput = 'false'
            break
    
    while True:
        input_printProg = input('Do you want AES to print the progress while running? (Y/N): ').capitalize()
        if input_printProg ==  'Y':
            printProg = 'true'
            break
        elif input_printProg == 'N':
            printProg = 'false'
            break
    
    while True:
        input_progInt = input('By what step do you want AES to print the progress? ')
        try:
            progInt = int(input_progInt)
            break
        except:
            print('Not a valid number!')
    
    while True:
        input_progRnd = input('To what decimal place do you want AES to round the progress? ')
        try:
            progRnd = int(input_progRnd)
            break
        except:
            print('Not a valid number!')
    
    while True:
        input_numberof_printKeys = input('What keys do you want AES to print during initialization? ').capitalize()
        if input_numberof_printKeys == 'all':
            numberof_printKeys = 'all'
            break
        else:
            try:
                numberof_printKeys = int(input_numberof_printKeys)
                break
            except:
                print('Not a valid number!')
    
    if numberof_printKeys == 'all':
        printKeys = 'all'
    else:
        printKeys_counter = 0
        printKeys = []
        while printKeys_counter != numberof_printKeys:
            while True:
                input_printKeysEntry = input('Enter key index: ')
                try:
                    printKeysEntry = int(input_printKeysEntry)
                    printKeys.append(printKeysEntry)
                    break
                except:
                    print('Not a valid number!')
            printKeys_counter += 1
        printKeys = list2str(printKeys)
    
    while True:
        input_numberof_printNumKeys = input('What combination indexes do you want AES to print during initialization? ').capitalize()
        if input_numberof_printNumKeys == 'all':
            numberof_printNumKeys = 'all'
            break
        else:
            try:
                numberof_printNumKeys = int(input_numberof_printNumKeys)
                break
            except:
                print('Not a valid number!')
    
    if numberof_printNumKeys == 'all':
        printNumKeys = 'all'
    else:
        printNumKeys_counter = 0
        printNumKeys = []
        while printNumKeys_counter != numberof_printNumKeys:
            while True:
                input_printNumKeysEntry = input('Enter combination index index: ')
                try:
                    printNumKeysEntry = int(input_printNumKeysEntry)
                    printNumKeys.append(printNumKeysEntry)
                    break
                except:
                    print('Not a valid number!')
            printNumKeys_counter += 1
            printNumKeys = list2str(printNumKeys)
    
    while True:
        input_printInputFrom = input('Do you want AES to print the input file name during initialization? (Y/N): ').capitalize()
        if input_printInputFrom ==  'Y':
            printInputFrom = 'true'
            break
        elif input_printInputFrom == 'N':
            printInputFrom = 'false'
            break
    
    while True:
        input_printOutputTo = input('Do you want AES to print the output file name during initialization? (Y/N): ').capitalize()
        if input_printOutputTo ==  'Y':
            printOutputTo = 'true'
            break
        elif input_printOutputTo == 'N':
            printOutputTo = 'false'
            break
    
    while True:
        input_printChkOutputTo = input('Do you want AES to print the check-output file name during initialization? (Y/N): ').capitalize()
        if input_printChkOutputTo ==  'Y':
            printChkOutputTo = 'true'
            break
        elif input_printChkOutputTo == 'N':
            printChkOutputTo = 'false'
            break
    
    while True:
        input_printOutputedTo = input('Do you want AES to print the outputed file name during the conclusion? (Y/N): ').capitalize()
        if input_printOutputedTo ==  'Y':
            printOutputedTo = 'true'
            break
        elif input_printOutputedTo == 'N':
            printOutputedTo = 'false'
            break
    
    while True:
        input_printChkOutputedTo = input('Do you want AES to print the check-outputed file name during the conclusion? (Y/N): ').capitalize()
        if input_printChkOutputedTo ==  'Y':
            printChkOutputedTo = 'true'
            break
        elif input_printChkOutputedTo == 'N':
            printChkOutputedTo = 'false'
            break
    
    while True:
        input_printInitSize = input('Do you want AES to print the size of the initial file during the conclusion? (Y/N): ').capitalize()
        if input_printInitSize ==  'Y':
            printInitSize = 'true'
            break
        elif input_printInitSize == 'N':
            printInitSize = 'false'
            break
    
    while True:
        input_printFinalSize = input('Do you want AES to print the size of the final file during the conclusion? (Y/N): ').capitalize()
        if input_printFinalSize ==  'Y':
            printFinalSize = 'true'
            break
        elif input_printFinalSize == 'N':
            printFinalSize = 'false'
            break
    
    while True:
        input_printCompRatio = input('Do you want AES to print the compression ratio of final/initial file sizes during the conclusion? (Y/N): ').capitalize()
        if input_printCompRatio ==  'Y':
            printCompRatio = 'true'
            break
        elif input_printCompRatio == 'N':
            printCompRatio = 'false'
            break
    
    encLtrs = input('What file type do you want the encrypted file to be? (No dot): ')
    decLtrs = input('What file type do you want the decrypted file to be? (No dot): ')
    chkLtrs = input('What file type do you want the check-decrypted file to be? (No dot): ')
else:
    if debug == 'default':
        printInput = 'true'
        printOutput = 'true'
        printProg = 'true'
        progInt = 5
        progRnd = 1
        
        printKeys = 'all'
        printNumKeys = 'all'
        printInputFrom = 'true'
        printOutputTo = 'true'
        printChkOutputTo = 'true'
        
        printOutputedTo = 'true'
        printChkOutputedTo = 'true'
        printInitSize = 'true'
        printFinalSize = 'true'
        printCompRatio = 'true'
        
        encLtrs = 'aes'
        decLtrs = 'dec'
        chkLtrs = 'ckt'
        
    if debug == 'hidden':
        printInput = 'false'
        printOutput = 'false'
        printProg = 'false'
        progInt = 5
        progRnd = 1
        
        printKeys = 'all'
        printNumKeys = 'all'
        printInputFrom = 'true'
        printOutputTo = 'true'
        printChkOutputTo = 'true'
        
        printOutputedTo = 'true'
        printChkOutputedTo = 'true'
        printInitSize = 'true'
        printFinalSize = 'true'
        printCompRatio = 'true'
        
        encLtrs = 'aes'
        decLtrs = 'dec'
        chkLtrs = 'ckt'

keysStr = list2str(keys)
numKeysStr = list2str(numKeys)

init_file.write('[Settings]\n')
init_file.close()

init_file = open('init.aesp', 'a')
init_file.write('input='+inputPath+'\n')
init_file.write('output='+outputPath+'\n')
init_file.write('chk_output='+chk_outputPath+'\n')
init_file.write('keys='+keysStr+'\n')
init_file.write('numKeys='+numKeysStr+'\n')
init_file.write('sequence='+sequence+'\n')

init_file.write('[Debug]\n')
init_file.write('printInput='+printInput+'\n')
init_file.write('printOutput='+printOutput+'\n')
init_file.write('printProg='+printProg+'\n')
init_file.write('progInt='+str(progInt)+'\n')
init_file.write('progRnd='+str(progRnd)+'\n')

init_file.write('[P_Input]\n')
init_file.write('printKeys='+printKeys+'\n')
init_file.write('printNumKeys='+printNumKeys+'\n')
init_file.write('printInputFrom='+printInputFrom+'\n')
init_file.write('printOutputTo='+printOutputTo+'\n')
init_file.write('printChkOutputTo='+printChkOutputTo+'\n')

init_file.write('[P_Output]\n')
init_file.write('printOutputedTo='+printOutputedTo+'\n')
init_file.write('printChkOutputedTo='+printChkOutputedTo+'\n')
init_file.write('printInitSize='+printInitSize+'\n')
init_file.write('printFinalSize='+printFinalSize+'\n')
init_file.write('printCompRatio='+printCompRatio+'\n')

init_file.write('[Adv]\n')
init_file.write('encLtrs='+encLtrs+'\n')
init_file.write('decLtrs='+decLtrs+'\n')
init_file.write('chkLtrs='+chkLtrs)

init_file.close()

done = input('Success!\nPress ENTER\RETURN to continue...')