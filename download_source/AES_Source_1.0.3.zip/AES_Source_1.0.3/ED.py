from subprocess import check_output
import random
import os

def set_properties ():
    properties = open('init.aesp', 'r')
    d_settings = ['', '', '', [randomStr(), randomStr(), randomStr()], [5, 5, 5], 'e']
    d_debug = ['true', 'true', 'true', 5, 1]
    h_debug = ['false', 'false', 'false', 101, 0]
    d_p_input = ['all', 'all', 'true', 'true', 'true']
    d_p_output = ['true', 'true', 'true', 'true', 'true']
    d_adv = ['.aes', '.aes.dec', '.aes.chk']

    settings = ['', '', '', [], [], 'e']
    debug = ['', '', '', 0, 0]
    p_input = ['', '', '', '', '']
    p_output = ['', '', '', '', '']
    adv = ['', '', '']

    mode = 0
    for command in properties:
        command = command.strip()
        if command == '[Settings]':
            mode = 1
        elif command == '[Debug]':
            mode = 2
        elif command == '[P_Input]':
            mode = 3
        elif command == '[P_Output]':
            mode = 4
        elif command == '[Adv]':
            mode = 5
        elif len(command) > 0 and command[0] == "[" and command[len(command)-1] == "]":
            mode = 0
        else:
            if mode == 1:
                if command[:6] == 'input=':
                    settings[0] = command[6:]
                elif command[:7] == 'output=':
                    settings[1] = command[7:]
                elif command[:11] == 'chk_output=':
                    settings[2] = command[11:]
                elif command[:5] == 'keys=':
                    if len(command[5:]) > 0:
                        settings[3] = string2List(command[5:], 'not_i')
                    else:
                        settings[3] = d_settings[3]
                elif command[:8] == 'numKeys=':
                    if len(command[8:]) > 0:
                        settings[4] = string2List(command[8:], 'i')
                    else:
                        settings[4] = d_settings[4]
                elif command[:9] == 'sequence=':
                    settings[5] = command[9:]
            elif mode == 2:
                if command[:11] == 'printInput=':
                    debug[0] = command[11:]
                elif command[:12] == 'printOutput=':
                    debug[1] = command[12:]
                elif command[:10] == 'printProg=':
                    debug[2] = command[10:]
                elif command[:8] == 'progInt=':
                    debug[3] = command[8:]
                elif command[:8] == 'progRnd=':
                    debug[4] = command[8:]
                elif command[:6] == 'debug=':
                    if command[6:] == 'default':
                        debug = d_debug
                    elif command[6:] == 'hidden':
                        debug = h_debug
            elif mode == 3:
                if command[:10] == 'printKeys=':
                    if (command[10] == '[') and (command[len(command)-1] == ']'):
                        p_input[0] = string2List(command[10:], 'i')
                    else:
                        p_input[0] = command[10:]
                elif command[:13] == 'printNumKeys=':
                    if (command[13] == '[') and (command[len(command)-1] == ']'):
                        p_input[1] = string2List(command[13:], 'i')
                    else:
                        p_input[1] = command[13:]
                elif command[:15] == 'printInputFrom=':
                    p_input[2] = command[15:]
                elif command[:14] == 'printOutputTo=':
                    p_input[3] = command[14:]
                elif command[:17] == 'printChkOutputTo=':
                    p_input[4] = command[17:]
            elif mode == 4:
                if command[:16] == 'printOutputedTo=':
                    p_output[0] = command[16:]
                elif command[:19] == 'printChkOutputedTo=':
                    p_output[1] = command[19:]
                elif command[:14] == 'printInitSize=':
                    p_output[2] = command[14:]
                elif command[:15] == 'printFinalSize=':
                    p_output[3] = command[15:]
                elif command[:15] == 'printCompRatio=':
                    p_output[4] = command[15:]
            elif mode == 5:
                if command[:8] == 'encLtrs=':
                    adv[0] = '.' + command[8:]
                elif command[:8] == 'decLtrs=':
                    adv[1] = '.' + command[8:]
                elif command[:8] == 'chkLtrs=':
                    adv[2] = '.' + command[8:]
    
    settingsCounter = 0
    while settingsCounter != len(settings):
        if len(settings[settingsCounter]) == 0:
            settings[settingsCounter] == d_settings[settingsCounter]
        settingsCounter += 1
    
    debugCounter = 0
    while debugCounter != len(debug):
        if typeStr(debug[debugCounter]) != "<class 'int'>":
            if len(debug[debugCounter]) == 0:
                debug[debugCounter] == d_debug[debugCounter]
        debugCounter += 1
    
    p_inputCounter = 0
    while p_inputCounter != len(p_input):
        if len(p_input[p_inputCounter]) == 0:
            p_input[p_inputCounter] == d_p_input[p_inputCounter]
        p_inputCounter += 1
    
    p_outputCounter = 0
    while p_outputCounter != len(p_output):
        if len(p_output[p_outputCounter]) == 0:
            p_output[p_outputCounter] == d_p_output[p_outputCounter]
        p_outputCounter += 1
    
    advCounter = 0
    while advCounter != len(adv):
        if len(adv[advCounter]) == 0:
            adv[advCounter] == d_adv[advCounter]
        advCounter += 1
    
    return settings, debug, p_input, p_output, adv

def randomStr():
    length = random.randint(1, 15)
    counter = 0
    fStr = ''
    while counter <= length:
        fStr += chr(random.randint(48, 126))
        counter += 1
    return fStr

def getSize (location):
    fileStr = ((str(check_output("dir " + location + " /a:-d", shell=True).decode())).split())[17]
    f_fileStr = ""
    for digit in fileStr:
        if digit != ",":
            f_fileStr += digit
    return int(f_fileStr)

def getSizeStr (location):
    intStr = getSize(location)
    letter = ""
    if intStr < 1000:
        letter = "B"
        fStr = str(intStr) + letter
    if intStr >= 1000 and intStr < 1000000:
        letter = "kB"
        fStr = str(intStr/1000) + letter
    if intStr >= 1000000 and intStr < 1000000000:
        letter = "MB"
        fStr = str(intStr/1000000) + letter
    if intStr >= 1000000000:
        letter = "GB"
        fStr = str(intStr/1000000000) + letter
    return fStr

def string2List (string, flag):
    theList = []
    string = string[1:len(string)-1]
    fStr = ''
    for chtr in string:
        if chtr == ',':
            if flag == 'i':
                theList.append(int(fStr))
            else:
                theList.append(fStr)
            fStr = ''
        else:
            fStr += chtr
    if flag == 'i':
        theList.append(int(fStr))
    else:
        theList.append(fStr)
    return theList

def list2Str (theList):
    fStr = ''
    for theEntry in theList:
        fStr += str(theEntry) + ', '
    fStr = fStr[:len(fStr)-2]
    return fStr

def typeStr (object):
    answer = str(type(object))
    return answer

def encrypt (letter, keys):
    divinant = 1
    #print(letter)
    number = ord(letter)
    answer = number
    for password in keys:
        if divinant % 3 == 0:
            answer -= password
        else:
            answer += password
        divinant += 1
    return chr(answer)

def decrypt (letter, keys):
    divinant = 1
    number = ord(letter)
    answer = number
    for password in keys:
        if divinant % 3 == 0:
            answer += password
        else:
            answer -= password
        divinant += 1
    try:
        return chr(answer)
    except:
        print(answer, letter, number, keys)

def sequence (string, keys, flag):
    if flag == 'e':
        return encrypt(string, keys)
    elif flag == 'd':
        return decrypt(string, keys)

def reverse (theList):
    counter = 1
    fList = []
    while True:
        try:
            fList.append(theList[len(theList)-counter])
            counter += 1
        except:
            return fList[:int(len(fList)/2)]

def encode (string, password, keyL):
    keys = []
    keySet = []
    for chtr in password:
        if len(keySet) == keyL:
            keys.append(keySet)
            keySet = []
        keySet.append(ord(chtr))
    keys.append(keySet)
    msg = string
    msg2 = ''
    for fourKeys in keys:
        #print(fourKeys)
        if len(fourKeys) == keyL:
            msg2 = encrypt(msg, fourKeys)
            msg = msg2
            fMsg = msg2
        else:
            fFourKeys = []
            for fourKeysEntry in fourKeys:
                fFourKeys.append(fourKeysEntry)
            while len(fFourKeys) != keyL:
                fFourKeys.append(1)
            #print(fFourKeys)
            fMsg = encrypt(msg, fFourKeys)
    return fMsg

def decode (string, password, keyL):
    keys = []
    keySet = []
    for chtr in password:
        if len(keySet) == keyL:
            keys.append(keySet)
            keySet = []
        keySet.append(ord(chtr))
    keys.append(keySet)
    msg = string
    msg2 = ''
    fourKeysSet = []
    for fourKeys in keys:
        if len(fourKeys) == keyL:
            fourKeysSet.append(fourKeys)
        else:
            fFourKeys = []
            for fourKeysEntry in fourKeys:
                fFourKeys.append(fourKeysEntry)
            while len(fFourKeys) != keyL:
                fFourKeys.append(1)
            fourKeysSet.append(fFourKeys)
    finalKeySet = reverse(fourKeysSet)
    for finalKeys in finalKeySet:
        msg2 = decrypt(msg, finalKeys)
        msg = msg2
        fMsg = msg2
    return fMsg

def fEncode (string, password, keyL):
    fStr = ''
    for chtr in string:
        fStr += encode(chtr, password, keyL)
    return fStr

def fDecode (string, password, keyL):
    fStr = ''
    for chtr in string:
        fStr += decode(chtr, password, keyL)
    return fStr

def threeDES (string, passwords, keyLs, flag):
    finalStr = ''
    if flag == 'e':
        answer1 = fEncode(string, passwords[0], keyLs[0])
        answer2 = fEncode(answer1, passwords[1], keyLs[1])
        finalStr = fEncode(answer2, passwords[2], keyLs[2])
    if flag == 'd':
        answer1 = fDecode(string, passwords[2], keyLs[2])
        answer2 = fDecode(answer1, passwords[1], keyLs[1])
        finalStr = fDecode(answer2, passwords[0], keyLs[0])
    return finalStr

os.system('cls')

propertiesList = set_properties()
settings = propertiesList[0]
debug = propertiesList[1]
p_input = propertiesList[2]
p_output = propertiesList[3]
adv = propertiesList[4]

input_file_path = settings[0]
output_file_path = settings[1]
if (settings[2] == 'false') or (settings[2] == ''):
    bool_chk_output = False
    chk_output_file_path = ''
else:
    bool_chk_output = True
    chk_output_file_path = settings[2]
iterations = len(settings[3])
passwords = settings[3]
num_passwords = settings[4]
flag = settings[5]

if debug[0].capitalize() == 'True':
    printInput = True
else:
    printInput = False
if debug[1].capitalize() == 'True':
    printOutput = True
else:
    printOutput = False
if debug[2].capitalize() == 'True':
    printProg = True
else:
    printProg = False
progInt = debug[3]
progRnd = debug[4]

if p_input[0] == 'all':
    printKeys = list2Str(passwords)
else:
    printKeys = ''
    for printKeyEntry in p_input[0]:
        printKeys += passwords[printKeyEntry-1] + ', '
    printKeys = printKeys[:len(printKeys)-2]
bPrintKeys = True
if len(p_input[0]) == 0:
    bPrintKeys = False
if p_input[1] == 'all':
    printNumKeys = list2Str(num_passwords)
else:
    printNumKeys = ''
    for printNumKeyEntry in p_input[1]:
        printNumKeys += str(num_passwords[printNumKeyEntry-1]) + ', '
    printNumKeys = printNumKeys[:len(printNumKeys)-2]
bPrintNumKeys = True
if len(p_input[1]) == 0:
    bPrintNumKeys = False
if p_input[2].capitalize() == 'True':
    printInputFrom = True
else:
    printInputFrom = False
if p_input[3].capitalize() == 'True':
    printOutputTo = True
else:
    printOutputTo = False
if p_input[4].capitalize() == 'True':
    printChkOutputTo = True
else:
    printChkOutputTo = False

if p_output[0].capitalize() == 'True':
    printOutputedTo = True
else:
    printOutputedTo = False
if p_output[1].capitalize() == 'True':
    printChkOutputedTo = True
else:
    printChkOutputedTo = False
if p_output[2].capitalize() == 'True':
    printInitSize = True
else:
    printInitSize = False
if p_output[3].capitalize() == 'True':
    printFinalSize = True
else:
    printFinalSize = False
if p_output[4].capitalize() == 'True':
    printCompRatio = True
else:
    printCompRatio = False

encLtrs = adv[0]
decLtrs = adv[1]
chkLtrs = adv[2]

textFileName = input_file_path
ciphertextFileName = output_file_path + encLtrs
plaintextFileName = chk_output_file_path + chkLtrs
dectextFileName = output_file_path + decLtrs

rPasswords = reverse(passwords)
rNumPasswords = reverse(num_passwords)

chkNumPassCounter = 0
for num_password in num_passwords:
    if num_password < 1:
        flag = 'error'
        print('Error! Combination index #' + str(chkNumPassCounter+1) + ' has erroneous value of ' + str(num_password) + ' which is less than 1.')
    chkNumPassCounter += 1
if flag == 'e':
    if printInput:
        if printInputFrom:
            print('Inputing from: ' + textFileName)
        if bPrintKeys:
            print('Encoding using key(s): ' + printKeys)
        if bPrintNumKeys:
            print('Encoding using combination(s): ' + printNumKeys)
        if printOutputTo:
            print('Outputing to: ' + ciphertextFileName)
        if printChkOutputTo and bool_chk_output:
            print('Check outputing to: ' + plaintextFileName)
    
    print('Reading file...')     
    
    text = ''
    textFile = open(textFileName, 'r', encoding='utf-8')
    for textLine in textFile:
        text += str(textLine)
    textFile.close()
    
    print('Encrypting file...')    
    
    ciphertext = text
    numPassCounter = 0
    for password in passwords:
        ciphertext = fEncode(ciphertext, password, num_passwords[numPassCounter])
        numPassCounter += 1   
    
    print('Writing file...')    
    
    os.system("copy /y " + textFileName + " " + ciphertextFileName)
    ciphertextFile = open(ciphertextFileName, 'w', encoding='utf-8')
    ciphertextFile.write(ciphertext)
    ciphertextFile.close()
    
    if bool_chk_output:
    
        print('Validating encryption...')    
        
        plaintext_r = ''
        plaintext_r_file = open(ciphertextFileName, 'r', encoding='utf-8')
        #plaintext_r_file = open(ciphertextFileName, 'rb')
        for plaintext_r_line in plaintext_r_file:
            plaintext_r += str(plaintext_r_line)
        plaintext_r_file.close()
        
        plaintext = plaintext_r
        rNumPassCounter = 0
        for rPassword in rPasswords:
            plaintext = fDecode(plaintext, rPassword, rNumPasswords[rNumPassCounter])
            rNumPassCounter += 1
        os.system("copy /y " + textFileName + " " + plaintextFileName)
        plaintextFile = open(plaintextFileName, 'w', encoding='utf-8')
        plaintextFile.write(plaintext)
        plaintextFile.close()
        
        if text == plaintext:
            print('Success!')
        else:
            print('Error! Plaintext does not match original text.')
    
    if printOutput:
        if printOutputedTo:
            print('Outputed to: ' + ciphertextFileName)
        if printChkOutputedTo and bool_chk_output:
            print('Check outputed to: ' + plaintextFileName)
        if printInitSize:
            print('Initial file size: ' + getSizeStr(textFileName))
        if printFinalSize:
            print('Final file size: ' + getSizeStr(ciphertextFileName))
        if printCompRatio:
            print('Compression ratio: ' + str(round((getSize(ciphertextFileName)*100/getSize(textFileName)), 1)) + '%')
if flag == 'd':
    if printInput:
        if printInputFrom:
            print('Inputing from: ' + textFileName)
        if bPrintKeys:
            print('Decoding using key(s): ' + printKeys)
        if bPrintNumKeys:
            print('Decoding using combination(s): ' + printNumKeys)
        if printOutputTo:
            print('Outputing to: ' + ciphertextFileName)
    
    print('Reading file...')
    
    ciphertext = ''
    ciphertextFile = open(textFileName, 'r', encoding='utf-8')
    for ciphertextLine in ciphertextFile:
        ciphertext += ciphertextLine
    ciphertextFile.close()
    
    print('Decrypting file...')
    
    plaintext = ciphertext
    numPassCounter = 0
    for password in passwords:
        plaintext = fDecode(plaintext, password, num_passwords[numPassCounter])
        numPassCounter += 1
    
    print('Writing file...')
    
    os.system("copy /y " + textFileName + " " + dectextFileName)
    dectextFile = open(dectextFileName, 'w', encoding='utf-8')
    dectextFile.write(plaintext)
    dectextFile.close()
    
    print('Success!')
    
    if printOutput:
        if printOutputedTo:
            print('Outputed to: ' + dectextFileName)
        if printInitSize:
            print('Initial file size: ' + getSizeStr(textFileName))
        if printFinalSize:
            print('Final file size: ' + getSizeStr(dectextFileName))
        if printCompRatio:
            print('Compression ratio: ' + str(round((getSize(dectextFileName)*100/getSize(textFileName)), 1)) + '%')
exitCode = input('Press ENTER/RETURN to exit...')